import React from "react";
import Clientone from "../../public/adobe.svg";
import Clientwo from "../../public/okta.svg";
import Clienthree from "../../public/loom.svg";
import Clientfour from "../../public/hashicorp.svg";
import Image from "next/image";
export const Slider = () => {
  return (
    <div className="">
      <div className="paddinglow-atsdj margin-btm-at-mobview">
        <p
          // className="trusted-para-at-hm-main-layout"
          className="trust-partner-list-at-home-layout"
        >
          TRUSTED BY 30,000+ BUSINESSES.
        </p>
        <div className="slider">
          <div className="slide-track">
            <div className="slide">
              <Image
                src={Clientone}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientwo}
                width={70}
                height={30}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clienthree}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientfour}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientone}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientwo}
                width={70}
                height={30}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clienthree}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientfour}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientone}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientwo}
                width={70}
                height={30}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clienthree}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientfour}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientone}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientwo}
                width={70}
                height={30}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clienthree}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientfour}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientone}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientwo}
                width={70}
                height={30}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clienthree}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientfour}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientone}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientwo}
                width={70}
                height={30}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clienthree}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientfour}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientone}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientwo}
                width={70}
                height={30}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clienthree}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
            <div className="slide">
              <Image
                src={Clientfour}
                width={100}
                height={50}
                alt="Picture of the author"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
